import React from 'react';

export class NavItem extends React.Component {

isActive() {
    if (this.props.activeNav === this.props.navName) {
        return 'active'
    }
}

render() {
    return (<a className={this.isActive()} href="#" onClick={this.props.setActive.bind(null, this.props.navName)}>{this.props.navName}</a>)
}
}